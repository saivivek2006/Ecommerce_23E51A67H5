// Pesticide and pest management database
const pestManagementDatabase = {
    // Common pests across crops
    aphids: {
        name: "Aphids",
        crops: ["wheat", "corn", "soybeans", "tomatoes", "lettuce", "cabbage", "spinach"],
        type: "insect",
        description: "Small, soft-bodied insects that suck plant juices",
        organic: [
            {
                name: "Neem Oil",
                application: "Spray 2-4ml per liter of water every 7-10 days",
                timing: "Early morning or evening",
                notes: "Safe for beneficial insects when used correctly"
            },
            {
                name: "Insecticidal Soap",
                application: "Mix 15-30ml per liter, spray directly on pests",
                timing: "When pests are visible",
                notes: "Rinse plants after 2-3 hours to prevent leaf damage"
            },
            {
                name: "Beneficial Insects (Ladybugs)",
                application: "Release 1500-4500 per hectare",
                timing: "When aphid population is moderate",
                notes: "Biological control, sustainable long-term solution"
            }
        ],
        chemical: [
            {
                name: "Imidacloprid",
                application: "0.5-1ml per liter as soil drench or spray",
                timing: "Early infestation",
                notes: "Systemic insecticide, follow PHI guidelines"
            },
            {
                name: "Acetamiprid",
                application: "0.5-0.75ml per liter foliar spray",
                timing: "Active infestation",
                notes: "Quick knockdown, 7-14 day retreatment interval"
            }
        ]
    },

    cutworms: {
        name: "Cutworms",
        crops: ["corn", "tomatoes", "cabbage", "lettuce"],
        type: "insect",
        description: "Caterpillars that cut young plants at soil level",
        organic: [
            {
                name: "Diatomaceous Earth",
                application: "Dust around plant base, 20-30g per sq.m",
                timing: "Evening application, after dew dries",
                notes: "Food-grade DE only, reapply after rain"
            },
            {
                name: "Bacillus thuringiensis (Bt)",
                application: "Mix 2-4g per liter, spray in evening",
                timing: "When larvae are small (early instars)",
                notes: "Biological insecticide, specific to caterpillars"
            }
        ],
        chemical: [
            {
                name: "Chlorpyrifos",
                application: "2-3ml per liter soil drench",
                timing: "Pre-planting or at first sign of damage",
                notes: "Apply in evening when larvae are active"
            }
        ]
    },

    fungalDiseases: {
        name: "Fungal Diseases (Blight, Mildew, Rust)",
        crops: ["tomatoes", "potatoes", "wheat", "lettuce", "spinach"],
        type: "disease",
        description: "Various fungal infections causing leaf spots, wilting, and crop loss",
        organic: [
            {
                name: "Copper Fungicide",
                application: "2-3g per liter spray, cover all plant surfaces",
                timing: "Preventive: before disease appears",
                notes: "Don't use during flowering, can harm beneficial insects"
            },
            {
                name: "Baking Soda Solution",
                application: "5g baking soda + 2ml oil per liter water",
                timing: "Early symptoms or preventive",
                notes: "Change soil pH temporarily, test on small area first"
            },
            {
                name: "Trichoderma",
                application: "5-10g per liter soil drench or seed treatment",
                timing: "Preventive application",
                notes: "Beneficial fungus, competes with pathogens"
            }
        ],
        chemical: [
            {
                name: "Mancozeb",
                application: "2-3g per liter foliar spray",
                timing: "Preventive or early infection",
                notes: "Protective fungicide, 7-14 day intervals"
            },
            {
                name: "Propiconazole",
                application: "1-2ml per liter spray",
                timing: "First sign of disease",
                notes: "Systemic fungicide, observe pre-harvest interval"
            }
        ]
    },

    rootRot: {
        name: "Root Rot",
        crops: ["tomatoes", "potatoes", "carrots", "onions"],
        type: "disease",
        description: "Soil-borne fungal disease causing root decay",
        organic: [
            {
                name: "Improved Drainage",
                application: "Install drainage systems or raised beds",
                timing: "Before planting",
                notes: "Prevention is key - avoid waterlogged conditions"
            },
            {
                name: "Trichoderma Soil Treatment",
                application: "10-20g per sq.m mixed into soil",
                timing: "Before planting or at first symptoms",
                notes: "Beneficial microorganisms suppress pathogens"
            }
        ],
        chemical: [
            {
                name: "Metalaxyl",
                application: "2-3ml per liter soil drench",
                timing: "Preventive or early symptoms",
                notes: "Systemic fungicide, water into root zone"
            }
        ]
    },

    thrips: {
        name: "Thrips",
        crops: ["tomatoes", "onions", "lettuce"],
        type: "insect", 
        description: "Tiny insects that rasp leaf surfaces and suck plant juices",
        organic: [
            {
                name: "Blue Sticky Traps",
                application: "Place 10-20 traps per hectare",
                timing: "Throughout growing season",
                notes: "Monitor and mass trap adults"
            },
            {
                name: "Predatory Mites",
                application: "Release 100-200 per sq.m",
                timing: "Early infestation",
                notes: "Biological control, works best in greenhouse"
            }
        ],
        chemical: [
            {
                name: "Spinosad",
                application: "1-2ml per liter foliar spray",
                timing: "When thrips are detected",
                notes: "Organic-approved in some regions, rotate with other modes"
            }
        ]
    },

    wireworms: {
        name: "Wireworms",
        crops: ["potatoes", "carrots", "corn"],
        type: "insect",
        description: "Soil-dwelling larvae that damage roots and tubers",
        organic: [
            {
                name: "Crop Rotation",
                application: "Avoid susceptible crops for 2-3 years",
                timing: "Long-term strategy",
                notes: "Plant non-host crops like legumes or brassicas"
            },
            {
                name: "Potato Trap Crops",
                application: "Plant potato pieces as bait, remove after 2 weeks",
                timing: "2-3 weeks before main crop planting",
                notes: "Reduces population in heavily infested fields"
            }
        ],
        chemical: [
            {
                name: "Thiamethoxam",
                application: "Seed treatment or soil application",
                timing: "At planting",
                notes: "Systemic protection for 60-90 days"
            }
        ]
    },

    slugsSnails: {
        name: "Slugs and Snails",
        crops: ["lettuce", "cabbage", "spinach"],
        type: "mollusk",
        description: "Soft-bodied pests that eat large holes in leaves",
        organic: [
            {
                name: "Iron Phosphate Baits",
                application: "Scatter 5-10g per sq.m around plants",
                timing: "Evening application when pests are active",
                notes: "Safe for pets and wildlife, organic-approved"
            },
            {
                name: "Copper Tape Barriers",
                application: "Install around plant beds or containers",
                timing: "Before pest season begins",
                notes: "Physical barrier, gives mild electric shock"
            },
            {
                name: "Beer Traps",
                application: "Shallow dishes filled with beer every 2-3 meters",
                timing: "Place in evening, empty in morning",
                notes: "Attracts and drowns slugs, replace every 2-3 days"
            }
        ],
        chemical: [
            {
                name: "Metaldehyde Baits",
                application: "Apply according to label rates",
                timing: "Evening application",
                notes: "Toxic to pets and wildlife - use with extreme caution"
            }
        ]
    }
};

// Crop-specific pest mappings
const cropPestMappings = {
    wheat: {
        primary: ["aphids", "fungalDiseases"],
        secondary: ["cutworms"],
        soilBased: ["rootRot"]
    },
    rice: {
        primary: ["fungalDiseases", "aphids"],
        secondary: ["thrips"],
        soilBased: ["rootRot"]
    },
    corn: {
        primary: ["cutworms", "aphids"],
        secondary: ["wireworms"],
        soilBased: ["rootRot"]
    },
    soybeans: {
        primary: ["aphids", "thrips"],
        secondary: ["cutworms"],
        soilBased: ["rootRot", "fungalDiseases"]
    },
    potatoes: {
        primary: ["wireworms", "fungalDiseases"],
        secondary: ["cutworms"],
        soilBased: ["rootRot"]
    },
    tomatoes: {
        primary: ["cutworms", "fungalDiseases", "thrips"],
        secondary: ["aphids"],
        soilBased: ["rootRot"]
    },
    carrots: {
        primary: ["wireworms"],
        secondary: ["aphids"],
        soilBased: ["rootRot", "fungalDiseases"]
    },
    lettuce: {
        primary: ["aphids", "slugsSnails", "thrips"],
        secondary: ["cutworms"],
        soilBased: ["fungalDiseases"]
    },
    onions: {
        primary: ["thrips"],
        secondary: ["wireworms"],
        soilBased: ["rootRot", "fungalDiseases"]
    },
    barley: {
        primary: ["aphids", "fungalDiseases"],
        secondary: ["cutworms"],
        soilBased: ["rootRot"]
    },
    cabbage: {
        primary: ["cutworms", "aphids", "slugsSnails"],
        secondary: ["fungalDiseases"],
        soilBased: []
    },
    spinach: {
        primary: ["aphids", "slugsSnails", "fungalDiseases"],
        secondary: [],
        soilBased: []
    }
};

// Fertilizer database with NPK content and usage information
const fertilizerDatabase = {
    // Nitrogen-rich fertilizers
    urea: {
        name: "Urea (46-0-0)",
        npk: { n: 46, p: 0, k: 0 },
        type: "synthetic",
        application: "2-4 kg per 100 sq.m",
        timing: "Pre-planting and during growing season",
        description: "High nitrogen content, quick release, water-soluble"
    },
    ammoniumSulfate: {
        name: "Ammonium Sulfate (21-0-0)",
        npk: { n: 21, p: 0, k: 0 },
        type: "synthetic",
        application: "3-6 kg per 100 sq.m",
        timing: "Throughout growing season",
        description: "Slower release nitrogen, also provides sulfur"
    },
    bloodMeal: {
        name: "Blood Meal (12-0-0)",
        npk: { n: 12, p: 0, k: 0 },
        type: "organic",
        application: "1-2 kg per 100 sq.m",
        timing: "Early season, avoid over-application",
        description: "Organic nitrogen source, fast-acting but can burn plants"
    },
    compost: {
        name: "Compost (3-2-2)",
        npk: { n: 3, p: 2, k: 2 },
        type: "organic",
        application: "10-20 kg per 100 sq.m",
        timing: "Any time, best before planting",
        description: "Slow release, improves soil structure and biology"
    },
    
    // Phosphorus-rich fertilizers
    superphosphate: {
        name: "Single Superphosphate (0-20-0)",
        npk: { n: 0, p: 20, k: 0 },
        type: "synthetic",
        application: "2-3 kg per 100 sq.m",
        timing: "Pre-planting, mix into soil",
        description: "Fast-available phosphorus, also contains calcium and sulfur"
    },
    boneMeal: {
        name: "Bone Meal (4-12-0)",
        npk: { n: 4, p: 12, k: 0 },
        type: "organic",
        application: "2-4 kg per 100 sq.m",
        timing: "Fall or early spring application",
        description: "Slow release phosphorus, also provides calcium"
    },
    rockPhosphate: {
        name: "Rock Phosphate (0-3-0)",
        npk: { n: 0, p: 3, k: 0 },
        type: "organic",
        application: "5-10 kg per 100 sq.m",
        timing: "Fall application for next season",
        description: "Very slow release, long-term phosphorus supply"
    },
    
    // Potassium-rich fertilizers
    muriateOfPotash: {
        name: "Muriate of Potash (0-0-60)",
        npk: { n: 0, p: 0, k: 60 },
        type: "synthetic",
        application: "1-2 kg per 100 sq.m",
        timing: "Pre-planting or side-dress during season",
        description: "High potassium content, chloride form"
    },
    sulfateOfPotash: {
        name: "Sulfate of Potash (0-0-50)",
        npk: { n: 0, p: 0, k: 50 },
        type: "synthetic",
        application: "1-2 kg per 100 sq.m",
        timing: "Pre-planting, better for chloride-sensitive crops",
        description: "Premium potassium source, sulfate form, no chloride"
    },
    woodAsh: {
        name: "Wood Ash (0-2-10)",
        npk: { n: 0, p: 2, k: 10 },
        type: "organic",
        application: "2-5 kg per 100 sq.m (use sparingly)",
        timing: "Fall or early spring",
        description: "Natural potassium source, raises soil pH, use moderately"
    },
    kelpMeal: {
        name: "Kelp Meal (1-0-12)",
        npk: { n: 1, p: 0, k: 12 },
        type: "organic",
        application: "1-2 kg per 100 sq.m",
        timing: "Any time during growing season",
        description: "Natural potassium plus micronutrients and growth hormones"
    },
    
    // Balanced fertilizers
    npk101010: {
        name: "Balanced NPK (10-10-10)",
        npk: { n: 10, p: 10, k: 10 },
        type: "synthetic",
        application: "3-5 kg per 100 sq.m",
        timing: "Pre-planting and mid-season",
        description: "General purpose, balanced nutrition"
    },
    npk202020: {
        name: "High Analysis NPK (20-20-20)",
        npk: { n: 20, p: 20, k: 20 },
        type: "synthetic",
        application: "1.5-3 kg per 100 sq.m",
        timing: "Dissolved in water for frequent feeding",
        description: "Concentrated balanced fertilizer, often water-soluble"
    },
    organicBlend: {
        name: "Organic Blend (5-3-4)",
        npk: { n: 5, p: 3, k: 4 },
        type: "organic",
        application: "5-8 kg per 100 sq.m",
        timing: "Pre-planting and mid-season",
        description: "Organic materials blend, slow and steady release"
    }
};

// Crop database with optimal growing conditions (adjusted for realistic NPK ranges)
const cropDatabase = {
    wheat: {
        name: "Wheat",
        key: "wheat",
        soilTypes: ["loam", "clay", "silt"],
        nitrogen: { min: 0.1, max: 3.0, optimal: 1.5 },
        phosphorus: { min: 0.05, max: 1.5, optimal: 0.3 },
        potassium: { min: 0.1, max: 2.0, optimal: 0.8 },
        description: "Hardy cereal crop, excellent for bread production"
    },
    rice: {
        name: "Rice",
        key: "rice",
        soilTypes: ["clay", "silt", "loam"],
        nitrogen: { min: 0.2, max: 4.0, optimal: 2.0 },
        phosphorus: { min: 0.05, max: 1.2, optimal: 0.4 },
        potassium: { min: 0.1, max: 2.5, optimal: 1.0 },
        description: "Water-loving staple crop, requires good water retention"
    },
    corn: {
        name: "Corn (Maize)",
        key: "corn",
        soilTypes: ["loam", "sandy", "silt"],
        nitrogen: { min: 0.3, max: 4.0, optimal: 2.2 },
        phosphorus: { min: 0.1, max: 1.5, optimal: 0.5 },
        potassium: { min: 0.2, max: 3.0, optimal: 1.2 },
        description: "High-yield crop requiring rich, well-draining soil"
    },
    soybeans: {
        name: "Soybeans",
        key: "soybeans",
        soilTypes: ["loam", "silt", "clay"],
        nitrogen: { min: 0.05, max: 2.0, optimal: 0.8 },
        phosphorus: { min: 0.1, max: 1.2, optimal: 0.4 },
        potassium: { min: 0.3, max: 2.5, optimal: 1.4 },
        description: "Nitrogen-fixing legume, improves soil fertility"
    },
    potatoes: {
        name: "Potatoes",
        key: "potatoes",
        soilTypes: ["sandy", "loam"],
        nitrogen: { min: 0.2, max: 2.5, optimal: 1.0 },
        phosphorus: { min: 0.1, max: 1.0, optimal: 0.3 },
        potassium: { min: 0.5, max: 3.0, optimal: 2.0 },
        description: "Root vegetable requiring loose, well-draining soil"
    },
    tomatoes: {
        name: "Tomatoes",
        key: "tomatoes",
        soilTypes: ["loam", "sandy", "silt"],
        nitrogen: { min: 0.3, max: 3.0, optimal: 1.5 },
        phosphorus: { min: 0.1, max: 1.2, optimal: 0.4 },
        potassium: { min: 0.5, max: 3.5, optimal: 2.2 },
        description: "High-value vegetable crop with long growing season"
    },
    carrots: {
        name: "Carrots",
        key: "carrots",
        soilTypes: ["sandy", "loam"],
        nitrogen: { min: 0.1, max: 2.0, optimal: 0.8 },
        phosphorus: { min: 0.05, max: 0.8, optimal: 0.25 },
        potassium: { min: 0.3, max: 2.2, optimal: 1.0 },
        description: "Root vegetable preferring deep, loose soil"
    },
    lettuce: {
        name: "Lettuce",
        key: "lettuce",
        soilTypes: ["loam", "silt", "sandy"],
        nitrogen: { min: 0.5, max: 3.5, optimal: 2.0 },
        phosphorus: { min: 0.1, max: 1.0, optimal: 0.4 },
        potassium: { min: 0.3, max: 2.0, optimal: 1.2 },
        description: "Fast-growing leafy green requiring consistent moisture"
    },
    onions: {
        name: "Onions",
        key: "onions",
        soilTypes: ["sandy", "loam", "silt"],
        nitrogen: { min: 0.2, max: 2.5, optimal: 1.0 },
        phosphorus: { min: 0.08, max: 0.8, optimal: 0.3 },
        potassium: { min: 0.2, max: 2.0, optimal: 0.9 },
        description: "Versatile bulb crop with good storage properties"
    },
    barley: {
        name: "Barley",
        key: "barley",
        soilTypes: ["loam", "clay", "sandy"],
        nitrogen: { min: 0.1, max: 2.5, optimal: 1.0 },
        phosphorus: { min: 0.05, max: 0.9, optimal: 0.25 },
        potassium: { min: 0.1, max: 1.8, optimal: 0.7 },
        description: "Hardy cereal crop, drought-tolerant"
    },
    cabbage: {
        name: "Cabbage",
        key: "cabbage",
        soilTypes: ["loam", "clay", "silt"],
        nitrogen: { min: 0.4, max: 3.0, optimal: 1.8 },
        phosphorus: { min: 0.1, max: 1.0, optimal: 0.4 },
        potassium: { min: 0.5, max: 2.5, optimal: 1.5 },
        description: "Cool-season vegetable with large heads"
    },
    spinach: {
        name: "Spinach",
        key: "spinach",
        soilTypes: ["loam", "silt"],
        nitrogen: { min: 0.3, max: 3.5, optimal: 2.2 },
        phosphorus: { min: 0.1, max: 1.2, optimal: 0.5 },
        potassium: { min: 0.4, max: 2.2, optimal: 1.3 },
        description: "Nutrient-dense leafy green, fast growing"
    }
};

function calculateCropScore(crop, soilType, nitrogen, phosphorus, potassium) {
    let score = 0;

    // Soil type compatibility (40 points)
    if (crop.soilTypes.includes(soilType)) {
        score += 40;
    } else {
        score += 15; // Some crops can adapt
    }

    // NPK scoring (60 points total - 20 each)
    const nutrients = [
        { value: nitrogen, range: crop.nitrogen, name: 'N' },
        { value: phosphorus, range: crop.phosphorus, name: 'P' },
        { value: potassium, range: crop.potassium, name: 'K' }
    ];

    nutrients.forEach(nutrient => {
        let nutrientScore = 0;
        
        if (nutrient.value >= nutrient.range.min && nutrient.value <= nutrient.range.max) {
            // Within acceptable range - calculate how close to optimal
            const distanceFromOptimal = Math.abs(nutrient.value - nutrient.range.optimal);
            const rangeSize = nutrient.range.max - nutrient.range.min;
            
            if (distanceFromOptimal === 0) {
                nutrientScore = 20; // Perfect match
            } else {
                const normalizedDistance = distanceFromOptimal / (rangeSize / 2);
                nutrientScore = Math.max(12, 20 * (1 - normalizedDistance * 0.4));
            }
        } else if (nutrient.value < nutrient.range.min) {
            // Below minimum - penalize but not too harshly
            const deficit = (nutrient.range.min - nutrient.value) / nutrient.range.min;
            nutrientScore = Math.max(0, 12 * (1 - deficit));
        } else {
            // Above maximum - usually less problematic than deficit
            const excess = (nutrient.value - nutrient.range.max) / nutrient.range.max;
            if (excess <= 0.5) {
                nutrientScore = Math.max(8, 15 * (1 - excess));
            } else {
                nutrientScore = Math.max(0, 8 * (1 - excess * 0.5));
            }
        }
        
        score += nutrientScore;
    });

    return Math.min(100, Math.max(0, Math.round(score * 10) / 10));
}

function getScoreColor(score) {
    if (score >= 80) return '#4CAF50';
    if (score >= 60) return '#FF9800';
    if (score >= 40) return '#FF5722';
    return '#F44336';
}

function getScoreLabel(score) {
    if (score >= 80) return 'Excellent Match';
    if (score >= 60) return 'Good Match';
    if (score >= 40) return 'Fair Match';
    return 'Poor Match';
}

function validateSoilConditions(nitrogen, phosphorus, potassium) {
    const issues = [];
    
    // Check for extremely low values (deficient soil)
    if (nitrogen < 0.05) issues.push("Nitrogen levels are extremely low (< 0.05%)");
    if (phosphorus < 0.02) issues.push("Phosphorus levels are extremely low (< 0.02%)");
    if (potassium < 0.05) issues.push("Potassium levels are extremely low (< 0.05%)");
    
    // Check for extremely high values (toxic levels)
    if (nitrogen > 5.0) issues.push("Nitrogen levels are dangerously high (> 5.0%) - risk of nutrient burn");
    if (phosphorus > 2.0) issues.push("Phosphorus levels are excessively high (> 2.0%) - may block other nutrients");
    if (potassium > 4.0) issues.push("Potassium levels are extremely high (> 4.0%) - may cause salt damage");
    
    // Check for severely imbalanced ratios
    const nToP = nitrogen / phosphorus;
    const nToK = nitrogen / potassium;
    
    if (nToP > 20) issues.push("Nitrogen to Phosphorus ratio is severely imbalanced (too much N relative to P)");
    if (nToP < 0.5) issues.push("Phosphorus levels are extremely high relative to Nitrogen");
    if (nToK > 10) issues.push("Nitrogen levels are too high relative to Potassium");
    if (nToK < 0.2) issues.push("Potassium levels are extremely high relative to Nitrogen");
    
    return issues;
}

function analyzeSoilDeficiencies(crop, nitrogen, phosphorus, potassium) {
    const deficiencies = [];
    const excesses = [];
    
    // Check against crop's optimal ranges
    if (nitrogen < crop.nitrogen.optimal * 0.7) {
        deficiencies.push({
            nutrient: 'nitrogen',
            current: nitrogen,
            optimal: crop.nitrogen.optimal,
            deficit: crop.nitrogen.optimal - nitrogen,
            severity: nitrogen < crop.nitrogen.min ? 'severe' : 'moderate'
        });
    } else if (nitrogen > crop.nitrogen.optimal * 1.5) {
        excesses.push({
            nutrient: 'nitrogen',
            current: nitrogen,
            optimal: crop.nitrogen.optimal,
            excess: nitrogen - crop.nitrogen.optimal
        });
    }
    
    if (phosphorus < crop.phosphorus.optimal * 0.7) {
        deficiencies.push({
            nutrient: 'phosphorus',
            current: phosphorus,
            optimal: crop.phosphorus.optimal,
            deficit: crop.phosphorus.optimal - phosphorus,
            severity: phosphorus < crop.phosphorus.min ? 'severe' : 'moderate'
        });
    } else if (phosphorus > crop.phosphorus.optimal * 1.5) {
        excesses.push({
            nutrient: 'phosphorus',
            current: phosphorus,
            optimal: crop.phosphorus.optimal,
            excess: phosphorus - crop.phosphorus.optimal
        });
    }
    
    if (potassium < crop.potassium.optimal * 0.7) {
        deficiencies.push({
            nutrient: 'potassium',
            current: potassium,
            optimal: crop.potassium.optimal,
            deficit: crop.potassium.optimal - potassium,
            severity: potassium < crop.potassium.min ? 'severe' : 'moderate'
        });
    } else if (potassium > crop.potassium.optimal * 1.5) {
        excesses.push({
            nutrient: 'potassium',
            current: potassium,
            optimal: crop.potassium.optimal,
            excess: potassium - crop.potassium.optimal
        });
    }
    
    return { deficiencies, excesses };
}

function recommendFertilizers(soilAnalysis, crop) {
    const recommendations = [];
    const { deficiencies, excesses } = soilAnalysis;
    
    if (deficiencies.length === 0 && excesses.length === 0) {
        // Soil is well balanced
        recommendations.push({
            fertilizer: fertilizerDatabase.compost,
            priority: 'maintenance',
            reason: 'Maintain soil health and provide slow-release nutrients',
            application: 'Apply annually to maintain soil organic matter'
        });
        return recommendations;
    }
    
    // Address deficiencies
    deficiencies.forEach(def => {
        switch (def.nutrient) {
            case 'nitrogen':
                if (def.severity === 'severe') {
                    recommendations.push({
                        fertilizer: fertilizerDatabase.urea,
                        priority: 'high',
                        reason: `Severe nitrogen deficiency (${def.deficit.toFixed(2)}% below optimal)`,
                        application: 'Apply immediately, split into 2-3 applications'
                    });
                } else {
                    recommendations.push({
                        fertilizer: fertilizerDatabase.compost,
                        priority: 'medium',
                        reason: `Moderate nitrogen deficiency (${def.deficit.toFixed(2)}% below optimal)`,
                       application: 'Apply organic matter for sustained nitrogen release'
                   });
               }
               break;
               
           case 'phosphorus':
               if (def.severity === 'severe') {
                   recommendations.push({
                       fertilizer: fertilizerDatabase.superphosphate,
                       priority: 'high',
                       reason: `Severe phosphorus deficiency (${def.deficit.toFixed(2)}% below optimal)`,
                       application: 'Apply before planting, work into root zone'
                   });
               } else {
                   recommendations.push({
                       fertilizer: fertilizerDatabase.boneMeal,
                       priority: 'medium',
                       reason: `Moderate phosphorus deficiency (${def.deficit.toFixed(2)}% below optimal)`,
                       application: 'Apply in fall or early spring for gradual release'
                   });
               }
               break;
               
           case 'potassium':
               if (def.severity === 'severe') {
                   recommendations.push({
                       fertilizer: fertilizerDatabase.muriateOfPotash,
                       priority: 'high',
                       reason: `Severe potassium deficiency (${def.deficit.toFixed(2)}% below optimal)`,
                       application: 'Apply before planting, avoid direct seed contact'
                   });
               } else {
                   recommendations.push({
                       fertilizer: fertilizerDatabase.kelpMeal,
                       priority: 'medium',
                       reason: `Moderate potassium deficiency (${def.deficit.toFixed(2)}% below optimal)`,
                       application: 'Apply during growing season for gradual improvement'
                   });
               }
               break;
       }
   });
   
   // Multiple deficiencies - recommend balanced fertilizer
   if (deficiencies.length >= 2) {
       recommendations.unshift({
           fertilizer: fertilizerDatabase.npk101010,
           priority: 'high',
           reason: 'Multiple nutrient deficiencies detected',
           application: 'Use as base fertilizer, then supplement specific nutrients'
       });
   }
   
   // Address excesses (mainly advisory)
   excesses.forEach(exc => {
       recommendations.push({
           fertilizer: null,
           priority: 'advisory',
           reason: `Excess ${exc.nutrient} detected (${exc.excess.toFixed(2)}% above optimal)`,
           application: `Avoid ${exc.nutrient}-rich fertilizers, consider soil leaching or dilution`
       });
   });
   
   // Always recommend organic matter
   if (!recommendations.find(r => r.fertilizer && r.fertilizer.type === 'organic')) {
       recommendations.push({
           fertilizer: fertilizerDatabase.compost,
           priority: 'low',
           reason: 'Improve overall soil health and biology',
           application: 'Apply annually regardless of nutrient levels'
       });
   }
   
   return recommendations.sort((a, b) => {
       const priorityOrder = { high: 0, medium: 1, low: 2, advisory: 3 };
       return priorityOrder[a.priority] - priorityOrder[b.priority];
   });
}

function getPestRecommendations(crop, soilType, nitrogen, phosphorus, potassium) {
   const cropKey = crop.key;
   const pestInfo = cropPestMappings[cropKey];
   
   if (!pestInfo) return [];
   
   const recommendations = [];
   
   // Get primary pests (always include)
   pestInfo.primary.forEach(pestKey => {
       const pest = pestManagementDatabase[pestKey];
       if (pest) {
           recommendations.push({
               pest: pest,
               priority: "high",
               reason: `Common major pest for ${crop.name}`
           });
       }
   });
   
   // Get secondary pests (moderate priority)
   pestInfo.secondary.forEach(pestKey => {
       const pest = pestManagementDatabase[pestKey];
       if (pest) {
           recommendations.push({
               pest: pest,
               priority: "medium", 
               reason: `Secondary concern for ${crop.name}`
           });
       }
   });
   
   // Soil-based issues (based on soil conditions)
   if (soilType === "clay" || nitrogen > 2.5) {
       // Heavy, wet soils or high nitrogen increase disease pressure
       pestInfo.soilBased.forEach(pestKey => {
           const pest = pestManagementDatabase[pestKey];
           if (pest && pest.type === "disease") {
               recommendations.push({
                   pest: pest,
                   priority: "high",
                   reason: `${soilType} soil and high nitrogen increase disease risk`
               });
           }
       });
   } else if (soilType === "sandy") {
       // Sandy soils favor certain soil pests
       pestInfo.soilBased.forEach(pestKey => {
           const pest = pestManagementDatabase[pestKey];
           if (pest && pestKey === "wireworms") {
               recommendations.push({
                   pest: pest,
                   priority: "medium",
                   reason: `Sandy soil favors wireworm development`
               });
           }
       });
   }
   
   return recommendations;
}

function generateFertilizerSection(crop, nitrogen, phosphorus, potassium) {
   const soilAnalysis = analyzeSoilDeficiencies(crop, nitrogen, phosphorus, potassium);
   const fertilizerRecs = recommendFertilizers(soilAnalysis, crop);
   
   if (fertilizerRecs.length === 0) return '';
   
   let html = `
       <div style="margin-top: 15px; padding: 12px; background: linear-gradient(135deg, #f0f8ff 0%, #e6f3ff 100%); border-radius: 8px; border-left: 3px solid #2196F3;">
           <div style="font-weight: 600; color: #1976D2; margin-bottom: 10px; display: flex; align-items: center;">
               <span style="margin-right: 8px;">🧪</span> Fertilizer Recommendations for ${crop.name}
           </div>
   `;
   
   fertilizerRecs.slice(0, 3).forEach(rec => {
       const priorityColor = {
           'high': '#f44336',
           'medium': '#ff9800', 
           'low': '#4caf50',
           'advisory': '#2196f3'
       };
       
       const priorityIcon = {
           'high': '🚨',
           'medium': '⚡',
           'low': '✅',
           'advisory': '💡'
       };
       
       if (rec.fertilizer) {
           html += `
               <div style="margin-bottom: 8px; padding: 8px; background: rgba(255,255,255,0.7); border-radius: 6px;">
                   <div style="display: flex; align-items: center; margin-bottom: 4px;">
                       <span style="margin-right: 6px;">${priorityIcon[rec.priority]}</span>
                       <strong style="color: #333; font-size: 14px;">${rec.fertilizer.name}</strong>
                       <span style="margin-left: auto; color: ${priorityColor[rec.priority]}; font-size: 12px; font-weight: 600;">
                           ${rec.priority.toUpperCase()}
                       </span>
                   </div>
                   <div style="font-size: 12px; color: #666; margin-bottom: 3px;">
                       <strong>Why:</strong> ${rec.reason}
                   </div>
                   <div style="font-size: 12px; color: #666; margin-bottom: 3px;">
                       <strong>How:</strong> ${rec.fertilizer.application}
                   </div>
                   <div style="font-size: 12px; color: #666;">
                       <strong>When:</strong> ${rec.fertilizer.timing}
                   </div>
               </div>
           `;
       } else {
           // Advisory message for excesses
           html += `
               <div style="margin-bottom: 8px; padding: 8px; background: rgba(255,243,205,0.7); border-radius: 6px;">
                   <div style="display: flex; align-items: center; margin-bottom: 4px;">
                       <span style="margin-right: 6px;">${priorityIcon[rec.priority]}</span>
                       <strong style="color: #856404; font-size: 14px;">Advisory</strong>
                   </div>
                   <div style="font-size: 12px; color: #856404;">
                       ${rec.reason}<br>
                       <strong>Action:</strong> ${rec.application}
                   </div>
               </div>
           `;
       }
   });
   
   html += '</div>';
   return html;
}

function generatePestSection(crop, soilType, nitrogen, phosphorus, potassium) {
   const pestRecs = getPestRecommendations(crop, soilType, nitrogen, phosphorus, potassium);
   
   if (pestRecs.length === 0) return '';
   
   let html = `
       <div style="margin-top: 15px; padding: 12px; background: linear-gradient(135deg, #fff8e1 0%, #ffecb3 100%); border-radius: 8px; border-left: 3px solid #ff9800;">
           <div style="font-weight: 600; color: #ef6c00; margin-bottom: 10px; display: flex; align-items: center;">
               <span style="margin-right: 8px;">🛡️</span> Pest & Disease Management for ${crop.name}
           </div>
   `;
   
   pestRecs.slice(0, 3).forEach(rec => {
       const priorityColor = {
           'high': '#f44336',
           'medium': '#ff9800',
           'low': '#4caf50'
       };
       
       const priorityIcon = {
           'high': '🚨',
           'medium': '⚠️',
           'low': '💡'
       };
       
       html += `
           <div style="margin-bottom: 12px; padding: 10px; background: rgba(255,255,255,0.8); border-radius: 6px;">
               <div style="display: flex; align-items: center; margin-bottom: 6px;">
                   <span style="margin-right: 6px;">${priorityIcon[rec.priority]}</span>
                   <strong style="color: #333; font-size: 14px;">${rec.pest.name}</strong>
                   <span style="margin-left: auto; color: ${priorityColor[rec.priority]}; font-size: 12px; font-weight: 600;">
                       ${rec.priority.toUpperCase()} PRIORITY
                   </span>
               </div>
               <div style="font-size: 12px; color: #666; margin-bottom: 6px;">
                   <strong>Issue:</strong> ${rec.pest.description}
               </div>
               <div style="font-size: 12px; color: #666; margin-bottom: 8px;">
                   <strong>Why for this crop:</strong> ${rec.reason}
               </div>
               
               <div style="margin-bottom: 8px;">
                   <div style="font-weight: 600; color: #2e7d32; font-size: 13px; margin-bottom: 4px;">🌱 Organic Solutions:</div>
       `;
       
       rec.pest.organic.slice(0, 2).forEach(treatment => {
           html += `
               <div style="margin-bottom: 4px; padding: 4px 8px; background: rgba(76,175,80,0.1); border-radius: 4px;">
                   <div style="font-weight: 600; font-size: 12px; color: #2e7d32;">${treatment.name}</div>
                   <div style="font-size: 11px; color: #555;">${treatment.application}</div>
                   <div style="font-size: 11px; color: #777; font-style: italic;">${treatment.notes}</div>
               </div>
           `;
       });
       
       html += `
               </div>
               
               <div>
                   <div style="font-weight: 600; color: #c62828; font-size: 13px; margin-bottom: 4px;">⚗️ Chemical Options:</div>
       `;
       
       rec.pest.chemical.slice(0, 1).forEach(treatment => {
           html += `
               <div style="margin-bottom: 4px; padding: 4px 8px; background: rgba(244,67,54,0.1); border-radius: 4px;">
                   <div style="font-weight: 600; font-size: 12px; color: #c62828;">${treatment.name}</div>
                   <div style="font-size: 11px; color: #555;">${treatment.application}</div>
                   <div style="font-size: 11px; color: #777; font-style: italic;">${treatment.notes}</div>
               </div>
           `;
       });
       
       html += `
               </div>
           </div>
       `;
   });
   
   html += `
           <div style="margin-top: 10px; padding: 8px; background: rgba(33,150,243,0.1); border-radius: 6px; font-size: 11px; color: #1565c0;">
               <strong>⚠️ Important:</strong> Always read and follow label instructions. Rotate between different modes of action to prevent resistance. Consider weather conditions and beneficial insect activity before applying treatments.
           </div>
       </div>
   `;
   
   return html;
}

document.getElementById('cropForm').addEventListener('submit', function(e) {
   e.preventDefault();
   
   const soilType = document.getElementById('soilType').value;
   const nitrogen = parseFloat(document.getElementById('nitrogen').value);
   const phosphorus = parseFloat(document.getElementById('phosphorus').value);
   const potassium = parseFloat(document.getElementById('potassium').value);
   const includeFertilizers = document.getElementById('includeFertilizers').checked;
   const includePesticides = document.getElementById('includePesticides').checked;

   // Validate soil conditions first
   const validationIssues = validateSoilConditions(nitrogen, phosphorus, potassium);
   
   const resultsDiv = document.getElementById('results');
   resultsDiv.innerHTML = '<div class="loading">Analyzing soil conditions</div>';

   setTimeout(() => {
       const recommendations = [];

       Object.keys(cropDatabase).forEach(cropKey => {
           const crop = cropDatabase[cropKey];
           const score = calculateCropScore(crop, soilType, nitrogen, phosphorus, potassium);
           recommendations.push({ ...crop, score });
       });

       recommendations.sort((a, b) => b.score - a.score);
       
       // Check if soil conditions are severely problematic
       const maxScore = recommendations[0].score;
       const hasValidationIssues = validationIssues.length > 0;
       const allScoresLow = maxScore < 25;

       let html = '';
       
       // Show validation warnings if any
       if (hasValidationIssues || allScoresLow) {
           html += `
               <div style="background: #fff3cd; border: 2px solid #ffc107; border-radius: 12px; padding: 20px; margin-bottom: 20px; box-shadow: 0 4px 15px rgba(255, 193, 7, 0.3);">
                   <div style="display: flex; align-items: center; margin-bottom: 15px;">
                       <span style="font-size: 24px; margin-right: 10px;">⚠️</span>
                       <strong style="color: #856404; font-size: 18px;">Soil Condition Alert</strong>
                   </div>
                   <div style="color: #856404; line-height: 1.6;">
                       <p><strong>Growing crops may be challenging with these conditions:</strong></p>
                       <ul style="margin: 10px 0; padding-left: 20px;">`;
           
           if (validationIssues.length > 0) {
               validationIssues.forEach(issue => {
                   html += `<li style="margin: 5px 0;">${issue}</li>`;
               });
           }
           
           if (allScoresLow) {
               html += `<li style="margin: 5px 0;">Overall nutrient profile is not optimal for most common crops</li>`;
           }
           
           html += `
                       </ul>
                       <div style="margin-top: 15px; padding: 10px; background: rgba(255, 255, 255, 0.7); border-radius: 8px;">
                           <strong>💡 Recommendations:</strong><br>
                           • Consider soil amendments (compost, fertilizers)<br>
                           • Test soil pH levels (should be 6.0-7.5 for most crops)<br>
                           • Consult with local agricultural extension services<br>
                           • Consider container gardening with quality potting mix
                       </div>
                   </div>
               </div>
           `;
       }
       
       // Show crop recommendations even with warnings
       if (maxScore > 10) {
           html += `<div style="margin-bottom: 15px; padding: 10px; background: #e8f4f8; border-radius: 8px; font-size: 14px;">
               <strong>Analysis for ${soilType} soil:</strong> N:${nitrogen}%, P:${phosphorus}%, K:${potassium}%
           </div>`;
           
           recommendations.slice(0, 8).forEach(crop => {
               if (crop.score > 10) {
                   const alertIcon = crop.score < 30 ? '⚠️ ' : crop.score < 50 ? '⚡ ' : '✅ ';
                   html += `
                       <div class="crop-card" style="${crop.score < 30 ? 'border-left-color: #ff9800; background: linear-gradient(135deg, #fff8e1 0%, #ffffff 100%);' : ''}">
                           <div class="crop-name">${alertIcon}${crop.name}</div>
                           <div class="crop-score" style="color: ${getScoreColor(crop.score)}">
                               ${crop.score}% - ${getScoreLabel(crop.score)}
                           </div>
                           <div class="crop-details">${crop.description}</div>
                           ${crop.score < 30 ? '<div style="color: #f57c00; font-size: 14px; margin-top: 8px;"><strong>Note:</strong> May require soil amendments for optimal growth</div>' : ''}
                           
                           ${includeFertilizers ? generateFertilizerSection(crop, nitrogen, phosphorus, potassium) : ''}
                           
                           ${includePesticides ? generatePestSection(crop, soilType, nitrogen, phosphorus, potassium) : ''}
                       </div>
                   `;
               }
           });
       } else {
           html += `
               <div style="background: #f8d7da; border: 2px solid #dc3545; border-radius: 12px; padding: 20px; text-align: center; box-shadow: 0 4px 15px rgba(220, 53, 69, 0.3);">
                   <div style="font-size: 48px; margin-bottom: 15px;">🚫</div>
                   <h3 style="color: #721c24; margin-bottom: 15px;">Cannot Grow Crops</h3>
                   <p style="color: #721c24; line-height: 1.6;">
                       The current soil conditions are not suitable for growing any common crops. 
                       The nutrient levels are either severely deficient or excessively high, 
                       making successful crop cultivation very unlikely.
                   </p>
                   <div style="margin-top: 20px; padding: 15px; background: rgba(255, 255, 255, 0.7); border-radius: 8px;">
                       <strong>🔄 Please:</strong><br>
                       • Verify your soil test results<br>
                       • Consider professional soil remediation<br>
                       • Try container gardening with commercial soil mix
                   </div>
               </div>
           `;
       }

       resultsDiv.innerHTML = html;
   }, 1500);
});

// Add some interactive effects
document.addEventListener('DOMContentLoaded', function() {
   document.querySelectorAll('input, select').forEach(input => {
       input.addEventListener('focus', function() {
           this.parentElement.style.transform = 'scale(1.02)';
       });
       
       input.addEventListener('blur', function() {
           this.parentElement.style.transform = 'scale(1)';
       });
   });
});