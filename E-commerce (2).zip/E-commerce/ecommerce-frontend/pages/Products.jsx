// src/pages/Products.jsx
import React, { useEffect, useState } from 'react'
import axios from 'axios'

const Products = () => {
  const [products, setProducts] = useState([])
  const [formData, setFormData] = useState({
    name: '',
    email: ''
  })

  // Fetch all products from backend
  useEffect(() => {
    fetchProducts()
  }, [])

  const fetchProducts = async () => {
    const res = await axios.get('http://localhost:8080/api/products')
    setProducts(res.data)
  }

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    await axios.post('http://localhost:8080/api/products', formData)
    setFormData({ name: '', email: '' })
    fetchProducts()
  }

  return (
    <div style={{ padding: '20px' }}>
      <h2>🛍️ Products</h2>

      <form onSubmit={handleSubmit} style={{ marginBottom: '20px' }}>
        <input
          type="text"
          name="name"
          placeholder="Product Name"
          value={formData.name}
          onChange={handleChange}
          required
        />
        <input
          type="email"
          name="email"
          placeholder="Product Email"
          value={formData.email}
          onChange={handleChange}
          required
        />
        <button type="submit">Add Product</button>
      </form>

      <table border="1" cellPadding="10">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
          </tr>
        </thead>
        <tbody>
          {products.map((p) => (
            <tr key={p.id}>
              <td>{p.id}</td>
              <td>{p.name}</td>
              <td>{p.email}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default Products
