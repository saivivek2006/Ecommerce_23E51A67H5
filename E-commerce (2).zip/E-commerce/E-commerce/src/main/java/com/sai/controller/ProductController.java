package com.sai.controller;



import com.sai.entity.Product;

import com.sai.service.ProductService;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.*;



import java.util.List;



@RestController

@RequestMapping("/api/products")

@CrossOrigin(origins = "*")

public class ProductController {



    @Autowired

    private ProductService productService;



    @PostMapping

    public Product createProduct(@RequestBody Product product) {

        return productService.createProduct(product);

    }



    @GetMapping

    public List<Product> getAllProducts() {

        return productService.getAllProducts();

    }



    @GetMapping("/{id}")

    public Product getProductById(@PathVariable String id) {

        return productService.getProductById(id);

    }



    @DeleteMapping("/{id}")

    public String deleteProduct(@PathVariable String id) {

        productService.deleteProduct(id);

        return "Product deleted with ID: " + id;

    }



    // Custom filter endpoints

    @GetMapping("/category/{category}")

    public List<Product> getByCategory(@PathVariable String category) {

        return productService.getByCategory(category);

    }



    @GetMapping("/search")

    public List<Product> searchByName(@RequestParam String keyword) {

        return productService.searchByName(keyword);

    }



    @GetMapping("/filter")

    public List<Product> filterByPriceRange(@RequestParam double min, @RequestParam double max) {

        return productService.filterByPriceRange(min, max);

    }

}