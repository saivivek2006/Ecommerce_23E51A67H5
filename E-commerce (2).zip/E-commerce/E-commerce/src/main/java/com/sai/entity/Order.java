package com.sai.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.util.List;

@Document(collection = "orders")
public class Order {

    @Id
    private String id;

    private String userId;  
    private List<OrderItem> products;  
    private double totalAmount;
    private String status;  
    private Date createdAt;
    
    public Order() {
        this.createdAt = new Date();  
    }

    public Order(String userId, List<OrderItem> products, double totalAmount, String status) {
        this.userId = userId;
        this.products = products;
        this.totalAmount = totalAmount;
        this.status = status;
        this.createdAt = new Date();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
       this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
       this.userId = userId;
    }

    public List<OrderItem> getProducts() {
        return products;
    }

    public void setProducts(List<OrderItem> products) {
       this.products = products;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
       this.totalAmount = totalAmount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
       this.status = status;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
       this.createdAt = createdAt;
    }
}