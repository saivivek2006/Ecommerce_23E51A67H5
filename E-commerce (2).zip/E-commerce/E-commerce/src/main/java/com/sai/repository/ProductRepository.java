package com.sai.repository;

import com.sai.entity.Product;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface ProductRepository extends MongoRepository<Product, String> {

	List<Product> findByNameContainingIgnoreCase(String keyword);

	List<Product> findByCategory(String category);

	List<Product> findByPriceBetween(double min, double max);
}