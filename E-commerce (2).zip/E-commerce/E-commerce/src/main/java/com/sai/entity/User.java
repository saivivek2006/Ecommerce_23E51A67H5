package com.sai.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="users")
public class User {
	@Id
	private String id;
	private String Username;
	private String email;
	private String password;
	private String role;
	private boolean isBlocked;

	public User() {
		
	}
	public User(String id, String username, String email, String password, String role, Boolean isBlocked) {
		super();
		this.id = id;
		Username = username;
		this.email = email;
		this.password = password;
		this.role = role;
		this.isBlocked = isBlocked;
	}
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUsername() {
		return Username;
	}

	public void setUsername(String username) {
		Username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Boolean getIsBlocked() {
		return isBlocked;
	}

	public void setIsBlocked(Boolean isBlocked) {
		this.isBlocked = isBlocked;
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", Username=" + Username + ", email=" + email + ", password=" + password + ", role="
				+ role + ", isBlocked=" + isBlocked + "]";
	}
}